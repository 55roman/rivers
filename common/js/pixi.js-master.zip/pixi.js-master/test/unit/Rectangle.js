define(function() {
    Q.module('Rectangle');
});
