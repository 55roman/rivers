define(function() {
    Q.module('Rope');
});
