define(function() {
    Q.module('CanvasRenderer');
});
